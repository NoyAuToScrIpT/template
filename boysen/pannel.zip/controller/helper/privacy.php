<?php

namespace Helper;

trait Privacy {

	function loadServer() {
		$f3 = \Base::instance();
		$server = $this->server;
		if ($f3->exists('PARAMS.id',$id)) {
			if ($this->me->isAdmin()) {
				$server->id($id);
				$server->reroute('/home/admin/server');
			} else {
				$server->load(array('id=?',$id));
				$server->reroute('/privacy');
			}
		}
		return $server;
	}

}