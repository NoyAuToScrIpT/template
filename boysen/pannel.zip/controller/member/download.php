<?php 

namespace Member;

class Download extends \Home {

	use \Helper\Download;

	protected
		$server;

		function beforeRoute($f3) {
			parent::beforeRoute($f3);
			if ( $this->me->isAdmin()) $f3->reroute('/home/admin/server');
			$this->server = new \Server;
		}
	
		function All($f3) {
			$server = $this->server->find(array());
			$f3->set('servers',$server);
			$f3->set('subcontent','download.html');
		}
	
		function Id($f3) {
			$server = $this->loadServer();
			$f3->set('server',$server);
			$f3->set('subcontent','member/server.html');
        }
    }