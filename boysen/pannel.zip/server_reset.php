<?php
     $servername = "localhost";
     $username = "root"; //db_username
     $password = "cup"; //db_password
     $dbname = "cup"; //database_name
     
     // Create connection
     $conn = new mysqli($servername, $username, $password, $dbname);
     // Check connection
     if ($conn->connect_error) {
         die("Connection failed: " . $conn->connect_error);
     }

     $update = "UPDATE server SET created = '0' WHERE id >= 1";
     $result = mysqli_query($conn, $update);
?>
